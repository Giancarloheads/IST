<?php 
    get_header();
    include 'elements/nav-community.php';
?>

<?php   
    include 'elements/key-resources.php';
    include 'elements/about-pre-footer.php';
    get_footer();
?>