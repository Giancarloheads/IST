jQuery(document).ready(function ($) {

    const contactForm =$('#contact-form');

    const cvForm  = $('#cv-form');

})