<?php 
    get_header();
?>
<?php 
    include_once 'elements/nav-campus.php'; 
?>
<?php 
    get_footer();
?>